package ca.yorku.apptest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.io.File;

public class vault_screen extends AppCompatActivity {
    String route = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vault_screen);

        RecyclerView recycler = findViewById(R.id.recycler);
        TextView files_text = findViewById(R.id.file_view);

        route = getIntent().getStringExtra("route");
        if (route != null) {
            File source = new File(route);
            File[] files = source.listFiles();

            if (files == null || files.length == 0) {
                files_text.setVisibility(View.VISIBLE);
                return;
            }
            files_text.setVisibility(View.INVISIBLE);
            recycler.setLayoutManager(new LinearLayoutManager(this));
            recycler.setAdapter(new recycle_adapter(getApplicationContext(), files));
        } else {
            Log.wtf("STRING_VALUES", "NULL" + route);
        }

//        try {

//        }catch (Exception e){
//            Log.wtf("STRING_VALUES","NULL"+e.getMessage());
//
//        }


    }
}